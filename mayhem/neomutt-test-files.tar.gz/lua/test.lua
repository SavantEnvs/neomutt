local num = 42
